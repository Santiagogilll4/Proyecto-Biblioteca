<?php


include_once('conexion.php');

$id = $_POST['id'];
$Nombre = $_POST['Nombre'];
$Edicion = $_POST['Edicion'];
$Autor = $_POST['Autor'];
$Categoria = $_POST['Categoria'];
$Localizacion = $_POST['Localizacion'];
$Editorial = $_POST['Editorial'];

echo "Los datos son los siguientes: <br>";
echo "$id,$Nombre,$Edicion,$Autor,$Categoria,$Localizacion,$Editorial";

$conectar = conn();
$sql = "INSERT INTO libros(id,Nombre,Edicion,Autor,Categoria,Localizacion,Editorial)
VALUES('$id','$Nombre','$Edicion','$Autor','$Categoria','$Localizacion','$Editorial')";
$resul = mysqli_query($conectar, $sql) or trigger_error("Query Failed! SQL- Error:" . mysqli_error($conectar), E_USER_ERROR);


?>