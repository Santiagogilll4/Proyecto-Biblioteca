function administrador() {
  var password = 1234;
  var usuario = "administrador";
  if (
    document.form.num.value == password &&
    document.form.txt.value == usuario
  ) {
    window.open("vistaAdministrador.html");
  } else {
    alert("Error vuelve a intendarlo");
  }
}

function bibliotecario() {
  var password = 2468;
  var usuario = "bibliotecario";
  if (
    document.form.num.value == password &&
    document.form.txt.value == usuario
  ) {
    window.open("vistaBibliotecario.html");
  } else {
    alert("Error vuelve a intendarlo");
  }
}

function Cliente() {
  var password = 1357;
  var usuario = "cliente";
  if (
    document.form.num.value == password &&
    document.form.txt.value == usuario
  ) {
    window.open("vistaCliente.html");
  } else {
    alert("Error vuelve a intendarlo");
  }
}
