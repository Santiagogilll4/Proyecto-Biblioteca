<body>
    <link rel="stylesheet" href="stylesTable.css">
    <link rel="stylesheet" href="styles2.css">
    <?php

    $inc = include("conexion.php");
    $conectar = conn();
    if ($inc) {
        $consulta = "SELECT*FROM libros";
        $resultado = mysqli_query($conectar, $consulta); ?>

    <center>
        <h1>Libros</h1>
        <table class="top-row background-top-row">
            <thead>
                <tr>
                    <th class="table2">Id</th>
                    <th class="table2">Nombre</th>
                    <th class="table2">Edicion</th>
                    <th class="table2">Autor</th>
                    <th class="table2">Categoria</th>
                    <th class="table2">Localizacion</th>
                    <th class="table2">Editorial</th>
                </tr>
            </thead>
            <?php
        if ($resultado) {
            while ($row = $resultado->fetch_array()) {
                $id = $row['id'];
                $Nombre = $row['Nombre'];
                $Edicion = $row['Edicion'];
                $Autor = $row['Autor'];
                $Categoria = $row['Categoria'];
                $Localizacion = $row['Localizacion'];
                $Editorial = $row['Editorial'];


            ?>
            <tbody>
                <tr>
                    <td class="table">
                        <?php echo $id; ?>
                    </td>
                    <td class="table">
                        <?php echo $Nombre; ?>
                    </td>
                    <td class="table">
                        <?php echo $Edicion; ?>
                    </td>
                    <td class="table">
                        <?php echo $Autor; ?>
                    </td>
                    <td class="table">
                        <?php echo $Categoria; ?>
                    </td>
                    <td class="table">
                        <?php echo $Localizacion; ?>
                    </td>
                    <td class="table">
                        <?php echo $Editorial; ?>
                    </td>
                </tr>
            </tbody>
            <?php
            }
        }
    }
            ?>
        </table>
        <br><br><br><br><br>
        <input type="submit" class="button" value="Regresar" onclick="location.href='menulibrosBiblio.html'">
    </center>
</body>