<?php

include_once('conexion.php');

$Id_mobiliario = $_POST['Id_mobiliario'];

$conectar = conn();

$sql = "DELETE FROM mobiliario WHERE Id_mobiliario='$Id_mobiliario'";
$resul = mysqli_query($conectar, $sql) or trigger_error("Query Failed! SQL- Error:" . mysqli_error($conectar), E_USER_ERROR);



?>