<?php
include_once('conexion.php');

$id_personal = $_POST['id_personal'];
$Nombre = $_POST['Nombre'];
$Puesto = $_POST['Puesto'];
$Edad = $_POST['Edad'];

$conectar = conn();
$sql = "UPDATE personal SET Nombre='$Nombre', Puesto='$Puesto', Edad='$Edad' WHERE id_personal='$id_personal'";

$resul = mysqli_query($conectar, $sql) or trigger_error("Query Failed! SQL- Error:" . mysqli_error($conectar), E_USER_ERROR);

?>