function registrar() {
  alert("Se ha registrado con exito!");
}

function eliminar() {
  alert("Se ha eliminado con exito");
}

function actualizar() {
  alert("Se ha actualizado con exito");
}

function limpiar() {
  Formulario.reset();
}
