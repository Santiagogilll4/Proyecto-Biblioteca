<?php
include_once('conexion.php');

$id_lector = $_POST['id_lector'];
$Nombre = $_POST['Nombre'];
$Edad = $_POST['Edad'];

$conectar = conn();
$sql = "UPDATE lector SET Nombre='$Nombre', Edad='$Edad' WHERE id_lector='$id_lector'";

$resul = mysqli_query($conectar, $sql) or trigger_error("Query Failed! SQL- Error:" . mysqli_error($conectar), E_USER_ERROR);

?>