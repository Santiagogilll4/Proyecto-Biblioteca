<?php
include_once('conexion.php');

$Id_Autor = $_POST['Id_Autor'];
$Nombre = $_POST['Nombre'];
$Epoca = $_POST['Epoca'];
$Categoria = $_POST['Categoria'];

$conectar = conn();
$sql = "INSERT INTO autores(Id_Autor,Nombre,Epoca,Categoria)
VALUES('$Id_Autor','$Nombre','$Epoca','$Categoria')";
$resul = mysqli_query($conectar, $sql) or trigger_error("Query Failed! SQL- Error:" . mysqli_error($conectar), E_USER_ERROR);

?>