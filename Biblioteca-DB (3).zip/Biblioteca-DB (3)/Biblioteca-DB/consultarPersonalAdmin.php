<body>
    <link rel="stylesheet" href="stylesTable.css">
    <link rel="stylesheet" href="styles2.css">
    <?php

    $inc = include("conexion.php");
    $conectar = conn();
    if ($inc) {
        $consulta = "SELECT*FROM personal";
        $resultado = mysqli_query($conectar, $consulta); ?>

    <center>
        <h1>Personal</h1>
        <table class="top-row background-top-row">
            <thead>
                <tr>
                    <th class="table2">id_personal</th>
                    <th class="table2">Nombre</th>
                    <th class="table2">Puesto</th>
                    <th class="table2">Edad</th>
                </tr>
            </thead>
            <?php
        if ($resultado) {
            while ($row = $resultado->fetch_array()) {
                $id_personal = $row['id_personal'];
                $Nombre = $row['Nombre'];
                $Puesto = $row['Puesto'];
                $Edad = $row['Edad'];

            ?>
            <tbody>
                <tr>
                    <td class="table">
                        <?php echo $id_personal; ?>
                    </td>
                    <td class="table">
                        <?php echo $Nombre; ?>
                    </td>
                    <td class="table">
                        <?php echo $Puesto; ?>
                    </td>
                    <td class="table">
                        <?php echo $Edad; ?>
                    </td>
                </tr>
            </tbody>
            <?php
            }
        }
    }
            ?>
        </table>
        <br><br><br><br><br>
        <input type="submit" class="button" value="Regresar" onclick="location.href='menuPersonalAdmin.html'">
    </center>
</body>