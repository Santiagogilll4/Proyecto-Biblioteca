<?php

include_once('conexion.php');

$id_personal = $_POST['id_personal'];
$Nombre = $_POST['Nombre'];
$Puesto = $_POST['Puesto'];
$Edad = $_POST['Edad'];

$conectar = conn();

$sql = "INSERT INTO personal(id_personal,Nombre,Puesto,Edad)
VALUES ('$id_personal','$Nombre','$Puesto','$Edad')";
$resul = mysqli_query($conectar, $sql) or trigger_error("Query Failed! SQL- Error:" . mysqli_error($conectar), E_USER_ERROR);


?>