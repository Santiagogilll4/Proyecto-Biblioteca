<body>
    <link rel="stylesheet" href="stylesTable.css">
    <link rel="stylesheet" href="styles2.css">
    <?php

    $inc = include("conexion.php");
    $conectar = conn();
    if ($inc) {
        $consulta = "SELECT*FROM autores";
        $resultado = mysqli_query($conectar, $consulta); ?>

    <center>
        <h1>Autores</h1>
        <table class="top-row background-top-row">
            <thead>
                <tr>
                    <th class="table2">Id_Autor</th>
                    <th class="table2">Nombre</th>
                    <th class="table2">Epoca</th>
                    <th class="table2">Categoria</th>
                </tr>
            </thead>
            <?php
        if ($resultado) {
            while ($row = $resultado->fetch_array()) {
                $Id_Autor = $row['Id_Autor'];
                $Nombre = $row['Nombre'];
                $Epoca = $row['Epoca'];
                $Categoria = $row['Categoria'];

            ?>
            <tbody>
                <tr>
                    <td class="table">
                        <?php echo $Id_Autor; ?>
                    </td>
                    <td class="table">
                        <?php echo $Nombre; ?>
                    </td>
                    <td class="table">
                        <?php echo $Epoca; ?>
                    </td>
                    <td class="table">
                        <?php echo $Categoria; ?>
                    </td>
                </tr>
            </tbody>
            <?php
            }
        }
    }
            ?>
        </table>
        <br><br><br><br><br>
        <input type="submit" class="button" value="Regresar" onclick="location.href='menuAutoresCliente.html'">

    </center>
</body>