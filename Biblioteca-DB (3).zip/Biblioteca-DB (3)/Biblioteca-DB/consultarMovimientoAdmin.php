<body>
    <link rel="stylesheet" href="stylesTable.css">
    <link rel="stylesheet" href="styles2.css">
    <?php

    $inc = include("conexion.php");
    $conectar = conn();
    if ($inc) {
        $consulta = "SELECT*FROM movimientos";
        $resultado = mysqli_query($conectar, $consulta); ?>

    <center>
        <h1>Movimientos</h1>
        <table class="top-row background-top-row">
            <thead>
                <tr>
                    <th class="table2">Id_movimientos</th>
                    <th class="table2">Id_libro</th>
                    <th class="table2">Id_lector</th>
                    <th class="table2">Id_personal</th>
                </tr>
            </thead>
            <?php
        if ($resultado) {
            while ($row = $resultado->fetch_array()) {
                $Id_movimiento = $row['Id_movimiento'];
                $Id_libros = $row['Id_libros'];
                $Id_Lector = $row['Id_Lector'];
                $Id_personal = $row['Id_personal'];

            ?>
            <tbody>
                <tr>
                    <td class="table">
                        <?php echo $Id_movimiento; ?>
                    </td>
                    <td class="table">
                        <?php echo $Id_libros; ?>
                    </td>
                    <td class="table">
                        <?php echo $Id_Lector; ?>
                    </td>
                    <td class="table">
                        <?php echo $Id_personal; ?>
                    </td>
                </tr>
            </tbody>
            <?php
            }
        }
    }
            ?>
        </table>
        <br><br><br><br><br>
        <input type="submit" class="button" value="Regresar" onclick="location.href='menuMovimientosAdmin.html'">
    </center>
</body>