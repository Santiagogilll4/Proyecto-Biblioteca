<?php

include_once('conexion.php');

$Id_mobiliario = $_POST['Id_mobiliario'];
$Zona = $_POST['Zona'];
$Tipo = $_POST['Tipo'];

$conectar = conn();

$sql = "INSERT INTO mobiliario(Id_mobiliario,Zona,Tipo)
VALUES ('$Id_mobiliario','$Zona','$Tipo')";
$resul = mysqli_query($conectar, $sql) or trigger_error("Query Failed! SQL- Error:" . mysqli_error($conectar), E_USER_ERROR);



?>