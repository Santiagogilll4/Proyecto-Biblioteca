<?php
include_once('conexion.php');

$Id_movimiento = $_POST['Id_movimiento'];
$Id_libros = $_POST['Id_libros'];
$Id_Lector = $_POST['Id_Lector'];
$Id_personal = $_POST['Id_personal'];

$conectar = conn();
$sql = "UPDATE movimientos SET Id_libros='$Id_libros', Id_Lector='$Id_Lector', Id_personal='$Id_personal' 
WHERE Id_movimiento='$Id_movimiento'";
$resul = mysqli_query($conectar, $sql) or trigger_error("Query Failed! SQL- Error:" . mysqli_error($conectar), E_USER_ERROR);

?>