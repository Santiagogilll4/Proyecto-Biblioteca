<?php

require 'conexion.php';

$consultar = "SELECT * FROM autores";
$query = mysqli_query($conectar, $consultar);
$array = mysqli_fetch_array($query);

?>