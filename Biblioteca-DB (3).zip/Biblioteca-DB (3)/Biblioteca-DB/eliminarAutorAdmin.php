<?php

include_once('conexion.php');

$Id_Autor = $_POST['Id_Autor'];
$Nombre = $_POST['Nombre'];

$conectar = conn();

$sql = "DELETE FROM autores WHERE Id_Autor= '$Id_Autor'";
$resul = mysqli_query($conectar, $sql) or trigger_error("Query Failed! SQL- Error:" . mysqli_error($conectar), E_USER_ERROR);


?>