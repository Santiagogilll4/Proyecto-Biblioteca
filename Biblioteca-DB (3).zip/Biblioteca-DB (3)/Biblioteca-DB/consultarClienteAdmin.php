<body>
    <link rel="stylesheet" href="stylesTable.css">
    <link rel="stylesheet" href="styles2.css">
    <?php

    $inc = include("conexion.php");
    $conectar = conn();
    if ($inc) {
        $consulta = "SELECT*FROM lector";
        $resultado = mysqli_query($conectar, $consulta); ?>

    <center>
        <h1>Lectores</h1>
        <table class="top-row background-top-row">
            <thead>
                <tr>
                    <th class="table2">id_lectorr</th>
                    <th class="table2">Nombre</th>
                    <th class="table2">Edad</th>
                </tr>
            </thead>
            <?php
        if ($resultado) {
            while ($row = $resultado->fetch_array()) {
                $Id_Autor = $row['id_lector'];
                $Nombre = $row['Nombre'];
                $Epoca = $row['Edad'];

            ?>
            <tbody>
                <tr>
                    <td class="table">
                        <?php echo $Id_Autor; ?>
                    </td>
                    <td class="table">
                        <?php echo $Nombre; ?>
                    </td>
                    <td class="table">
                        <?php echo $Epoca; ?>
                    </td>
                </tr>
            </tbody>
            <?php
            }
        }
    }
            ?>
        </table>
        <br><br><br><br><br>
        <input type="submit" class="button" value="Regresar" onclick="location.href='menuClientesAdmin.html'">
    </center>

</body>