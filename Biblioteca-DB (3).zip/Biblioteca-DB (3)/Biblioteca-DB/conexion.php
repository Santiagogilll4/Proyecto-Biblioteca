<?php
function conn()
{
    $hostname = 'localhost';
    $useriodb = 'root';
    $passworddb = '14159265';
    $dbname = "biblioteca";

    $conectar = mysqli_connect($hostname, $useriodb, $passworddb, $dbname);
    return $conectar;
}
?>