<?php

include_once('conexion.php');

?>
<link rel="stylesheet" href="stylesTable.css">
<link rel="stylesheet" href="styles2.css">

<body>
    <form class="formularioR" name="formR" action="mostrar()">
        <h1>Consultar Autor</h1>
        <div class="contenedor">
            <h2>Id</h2>
            <input type="number" name="Id-Autor" placeholder="Id" required>
        </div>
        <div class="contenedor">
            <h2>Nombre</h2>
            <input type="text" name="Nombre" placeholder="Nombre" required>
        </div>
    </form>


    <?php

    function mostrar()
    {

        $conectar = conn();
        $Id_Autor = $_POST['Id_Autor'];

        $sql = "SELECT*FROM autores where Id_Autor='$Id_Autor'";
        $resul = mysqli_query($conectar, $sql);


    ?>

    <center>
        <table class="top-row background-top-row">
            <thead>
                <tr>
                    <th class="table2">Id-Autor</th>
                    <th class="table2">Nombre</th>
                    <th class="table2">Epoca</th>
                    <th class="table2">Categoria</th>
                </tr>
            </thead>
            <?php
        if ($resul) {
            while ($row = $resul->fetch_array()) {
                $Id_Autor = $row['Id_Autor'];
                $Nombre = $row['Nombre'];
                $Epoca = $row['Epoca'];
                $Categoria = $row['Categoria'];
            ?>
            <tbody>
                <tr>
                    <td class="table">
                        <?php echo $Id_Autor; ?>
                    </td>
                    <td class="table">
                        <?php echo $Nombre; ?>
                    </td>
                    <td class="table">
                        <?php echo $Epoca; ?>
                    </td>
                    <td class="table">
                        <?php echo $Categoria; ?>
                    </td>
                </tr>
            </tbody>
            <?php
            }
        }
    }
            ?>
        </table>
    </center>

</body>