<?php
include_once('conexion.php');

$id_lector = $_POST['id_lector'];
$Nombre = $_POST['Nombre'];
$Edad = $_POST['Edad'];

$conectar = conn();
$sql = "INSERT INTO lector(id_lector,Nombre,Edad)
VALUES('$id_lector','$Nombre','$Edad')";

$resul = mysqli_query($conectar, $sql) or trigger_error("Query Failed! SQL- Error:" . mysqli_error($conectar), E_USER_ERROR);

?>