<?php

include_once('conexion.php');

$Id_movimiento = $_POST['Id_movimiento'];

$conectar = conn();

$sql = "DELETE FROM movimientos WHERE Id_movimiento='$Id_movimiento'";
$resul = mysqli_query($conectar, $sql) or trigger_error("Query Failed! SQL- Error:" . mysqli_error($conectar), E_USER_ERROR);



?>